const express = require('express');
const server = express();

const app = require("./app");

server.get('/', function (req, res) {
    res.send('<html></html>');
});

server.get('/download', function (req, res) {

    app.execute(res).then((fileNameZip) => {
        // res.send(`todas imagens baixadas ${fileNameZip}`);
        const file = `${__dirname}\\${fileNameZip}`;
        console.log("downloading file", file);
        res.download(file);
    });

});

server.listen(3000, function () {
    console.log('Example app listening on port 3000!');
});